<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login</title>
</head>
<style>
   .kotak {
      width: 300px;
      border: solid 1px black;
      padding: 20px;
   }
</style>

<body>
   <center>
      <div class="kotak">
         <h1>Form Login</h1>
         <a href="<?= $url_auth_google; ?>">Login google</a>
      </div>
   </center>
</body>

</html>